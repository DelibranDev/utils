import React, { useMemo, useState } from "react";
import { MdFilterAlt, MdArrowUpward, MdArrowDownward } from "react-icons/md";

const STATUS_LABELS = {
  pending: "Pendiente",
  prepared: "Preparado",
  paid: "Pagado",
  shipped: "Enviado",
  inPreparation: "En preparación",
  inDelivery: "En reparto",
  canceled: "Cancelado",
};

const getObjectLabel = (value) => {
  if (value === null || value === undefined) return "";
  if (typeof value !== "object") return value;

  return value.name ?? value.fullname ?? value.street ?? value.identifier ?? value.email ?? value.number ?? JSON.stringify(value);
};

const isIsoDate = (value) =>
  typeof value === "string" && /^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(value) && !Number.isNaN(new Date(value).getTime());

const getFilterType = (values) => {
  const validValues = values.filter((value) => value !== null && value !== undefined && value !== "");

  if (validValues.length === 0) return "select";
  if (validValues.every((value) => typeof value === "number")) return "number";
  if (validValues.every((value) => isIsoDate(value))) return "date";

  return "select";
};

const getDisplayValue = (field, value) => {
  if (field === "status" || field === "paymentStatus") {
    return STATUS_LABELS[value] ?? value;
  }

  if (typeof value === "boolean") return value ? "Sí" : "No";

  return String(getObjectLabel(value));
};

const isArrayColumn = (values) => {
  const validValues = values.filter((value) => value !== null && value !== undefined);

  return validValues.length > 0 && validValues.every((value) => Array.isArray(value));
};

const renderCustomDataSafely = (renderer, value, row) => {
  try {
    return renderer(value, row);
  } catch (error) {
    if (value === null || value === undefined) {
      try {
        return renderer([], row);
      } catch {
        // Re-lanzamos el error original para no ocultar errores reales del renderer.
      }
    }

    throw error;
  }
};

const getCustomDataValue = (value, values) => {
  if ((value === null || value === undefined) && isArrayColumn(values)) {
    return [];
  }

  return value;
};

const ColumnFilter = ({ field, values, filter, onChange, onClose }) => {
  const filterType = getFilterType(values);

  if (filterType === "number") {
    return (
      <div className="columnFilterPopover" onClick={(event) => event.stopPropagation()}>
        <label>
          Mínimo
          <input
            type="number"
            value={filter?.min ?? ""}
            onChange={(event) =>
              onChange({
                type: "number",
                min: event.target.value,
                max: filter?.max ?? "",
              })
            }
          />
        </label>

        <label>
          Máximo
          <input
            type="number"
            value={filter?.max ?? ""}
            onChange={(event) =>
              onChange({
                type: "number",
                min: filter?.min ?? "",
                max: event.target.value,
              })
            }
          />
        </label>

        <button type="button" className="columnFilterClose" onClick={onClose}>
          Cerrar
        </button>
      </div>
    );
  }

  if (filterType === "date") {
    return (
      <div className="columnFilterPopover" onClick={(event) => event.stopPropagation()}>
        <label>
          Desde
          <input
            type="date"
            value={filter?.from ?? ""}
            onChange={(event) =>
              onChange({
                type: "date",
                from: event.target.value,
                to: filter?.to ?? "",
              })
            }
          />
        </label>

        <label>
          Hasta
          <input
            type="date"
            value={filter?.to ?? ""}
            onChange={(event) =>
              onChange({
                type: "date",
                from: filter?.from ?? "",
                to: event.target.value,
              })
            }
          />
        </label>

        <button type="button" className="columnFilterClose" onClick={onClose}>
          Cerrar
        </button>
      </div>
    );
  }

  const uniqueValues = Array.from(
    new Map(
      values
        .filter((value) => value !== null && value !== undefined && value !== "")
        .map((value) => [String(getObjectLabel(value)), value]),
    ).values(),
  ).sort((a, b) =>
    getDisplayValue(field, a).localeCompare(getDisplayValue(field, b), "es", {
      numeric: true,
      sensitivity: "base",
    }),
  );

  return (
    <div className="columnFilterPopover" onClick={(event) => event.stopPropagation()}>
      <select value={filter?.value ?? ""} onChange={(event) => onChange({ type: "select", value: event.target.value })}>
        <option value="">Todos</option>

        {uniqueValues.map((value) => {
          const rawValue = String(getObjectLabel(value));

          return (
            <option key={rawValue} value={rawValue}>
              {getDisplayValue(field, value)}
            </option>
          );
        })}
      </select>

      <button type="button" className="columnFilterClose" onClick={onClose}>
        Cerrar
      </button>
    </div>
  );
};

export const DatatableComponent = ({
  checkColumn = false,
  data = [],
  customHeaders = {},
  customHeadersStyle = {},
  rows = [],
  selectedRows = [],
  customData = {},
  rowCallback = () => {},
  handleSelectRow = () => {},
  visibleColumns = [],
  columnFilters = {},
  handleColumnFilter = () => {},
  sortConfig = {},
  handleSort = () => {},
}) => {
  const [openFilterColumn, setOpenFilterColumn] = useState(null);

  const MIN_WIDTH = 120;
  const MAX_AUTO_WIDTH = 320;
  const HEADER_ACTIONS_WIDTH = 58;

  const columns = useMemo(
    () => Object.keys(customHeaders).filter((field) => visibleColumns.includes(field)),
    [customHeaders, visibleColumns],
  );

  const columnWidths = useMemo(() => {
    const widths = {};

    columns.forEach((field) => {
      const configuredWidth = Number(customHeadersStyle[field]?.width);

      if (Number.isFinite(configuredWidth) && configuredWidth > 0) {
        widths[field] = configuredWidth;
        return;
      }

      const headerLabel = String(customHeaders[field] ?? "");
      const headerWidth = headerLabel.length * 8 + HEADER_ACTIONS_WIDTH + 24;

      let contentWidth = MIN_WIDTH;

      rows.forEach((item) => {
        const value = getObjectLabel(item?.[field]);
        const isDataImage = typeof value === "string" && value.startsWith("data:image");

        if (typeof value === "number" || (typeof value === "string" && !isDataImage)) {
          contentWidth = Math.max(contentWidth, Math.min(String(value).length * 8 + 20, MAX_AUTO_WIDTH));
        }
      });

      widths[field] = Math.max(MIN_WIDTH, Math.min(Math.max(headerWidth, contentWidth), MAX_AUTO_WIDTH));
    });

    return widths;
  }, [columns, customHeaders, customHeadersStyle, rows]);

  return (
    <div className="desktopDatatable">
      <div className="table-container">
        <table className="datatableTable" cellSpacing="0">
          <thead>
            <tr>
              {checkColumn && (
                <th className="text-align-center datatableCheckboxColumn" style={{ width: "50px", minWidth: "50px" }} />
              )}

              {columns.map((field, columnIndex) => {
                const values = data.map((item) => item?.[field]);
                const columnIsArray = isArrayColumn(values);

                const isFilterable = customHeadersStyle[field]?.filterable !== false && !columnIsArray;

                const isSortable = customHeadersStyle[field]?.sortable !== false && !columnIsArray;

                const hasFilter = isFilterable && Boolean(columnFilters[field]);

                const isSorted = isSortable && sortConfig.column === field && Boolean(sortConfig.direction);

                const width = columnWidths[field];

                return (
                  <th
                    key={field}
                    className={`text-align-center datatableHeaderCell ${columnIndex === 0 ? "datatableHeaderCellFirst" : ""}`}
                    style={{
                      width: `${width}px`,
                      minWidth: `${width}px`,
                      maxWidth: `${width}px`,
                    }}
                  >
                    <div className="datatableHeaderContent">
                      <span className="datatableHeaderLabel" title={String(customHeaders[field] ?? "")}>
                        {customHeaders[field]}
                      </span>

                      <div className="datatableHeaderActions">
                        {isSortable && (
                          <button
                            type="button"
                            className={`datatableHeaderIcon ${isSorted ? "active" : ""}`}
                            title="Ordenar"
                            onClick={(event) => {
                              event.stopPropagation();
                              handleSort(field);
                            }}
                          >
                            {isSorted && sortConfig.direction === "desc" ? <MdArrowDownward /> : <MdArrowUpward />}
                          </button>
                        )}

                        {isFilterable && (
                          <button
                            type="button"
                            className={`datatableHeaderIcon ${hasFilter ? "active" : ""}`}
                            title="Filtrar"
                            onClick={(event) => {
                              event.stopPropagation();
                              setOpenFilterColumn((current) => (current === field ? null : field));
                            }}
                          >
                            <MdFilterAlt />
                          </button>
                        )}
                      </div>
                    </div>

                    {isFilterable && openFilterColumn === field && (
                      <ColumnFilter
                        field={field}
                        values={values}
                        filter={columnFilters[field]}
                        onChange={(filter) => handleColumnFilter(field, filter)}
                        onClose={() => setOpenFilterColumn(null)}
                      />
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>

          <tbody id="datatableTBody">
            {rows.map((row, rowIndex) => (
              <tr key={row.id || row.orderId || rowIndex} className={selectedRows.includes(row.id) ? "rowSelected" : ""}>
                {checkColumn && (
                  <td
                    className="text-align-center checkboxtd datatableCheckboxColumn"
                    style={{
                      width: "50px",
                      minWidth: "50px",
                      maxWidth: "50px",
                    }}
                  >
                    <input
                      type="checkbox"
                      className="custom-checkbox"
                      onChange={(event) => handleSelectRow(row.id, event.target.checked)}
                      checked={selectedRows.includes(row.id)}
                    />
                  </td>
                )}

                {columns.map((field) => {
                  const fieldValues = data.map((item) => item?.[field]);

                  const cellValue = getCustomDataValue(row[field], fieldValues);

                  const width = columnWidths[field];

                  return (
                    <td
                      key={field}
                      className="text-align-center datatableCell"
                      style={{
                        width: `${width}px`,
                        minWidth: `${width}px`,
                        maxWidth: `${width}px`,
                      }}
                      onClick={
                        typeof row[field] === "boolean" || row[field] === "PUBLISHED" || row[field] === "DRAFT"
                          ? undefined
                          : () => rowCallback(row)
                      }
                    >
                      {customData[field]
                        ? renderCustomDataSafely(customData[field], cellValue, row)
                        : field === "status" || field === "paymentStatus"
                          ? (STATUS_LABELS[row[field]] ?? row[field])
                          : row[field]}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
